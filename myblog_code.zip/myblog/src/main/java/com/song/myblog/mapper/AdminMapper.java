package com.song.myblog.mapper;

import com.song.myblog.bean.Admin;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AdminMapper {


    //for login management system
    @Select("SELECT * FROM tb_admin WHERE name=#{name} AND pwd=#{pwd}")
    Admin getAdminByNameAndPwd(String name, String pwd);

    @Select("SElECT * FROM tb_admin")
    List<Admin> getAll();
}

