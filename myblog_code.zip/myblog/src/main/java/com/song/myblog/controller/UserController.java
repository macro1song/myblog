package com.song.myblog.controller;

import com.song.myblog.bean.Message;
import com.song.myblog.bean.User;
import com.song.myblog.service.UserService;
import com.song.myblog.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserService   userService ;
    @PostMapping("/user-list")
    @ResponseBody
    public Message  getAll(  HttpSession session) {
        System.out.println("getAll:");
        List<User> users = userService.getAll();
        System.out.println("users:" + users);
        if (null == users) {
            return new Message(Constant.MSG_NO, "no");
        }
        session.setAttribute("users", users);
        session.setAttribute("userCount", users.size());// 共有数据
        return new Message(Constant.MSG_OK, "ok");
    }

}
