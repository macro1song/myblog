package com.song.myblog.controller;

import com.song.myblog.bean.ThumbUp;
import com.song.myblog.service.ThumbUpService;
import com.song.myblog.util.HighchartsUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

//点赞统计
@Controller
public class ThumbUpController {
    @Autowired
    private ThumbUpService thumbUpService;

    @GetMapping("/thumb-up-getColumn")
    @ResponseBody
    public String getColumn() { //ajax 默认为GetMapping
        List<ThumbUp> thumbUps = thumbUpService.getAll();
        System.out.println(thumbUps);
        List<Integer> xAxis=new ArrayList<>();//id集合
        List<Integer> data=new ArrayList<>();//对应id点赞数
        for (ThumbUp thumbUp: thumbUps) {
            xAxis.add(thumbUp.getBlogid());
            data.add(thumbUp.getUpNum());
        }
        String  option=  HighchartsUtil.getColumn( xAxis, data);
        System.out.println(option);
        return  option;
    }

    @GetMapping("/thumb-up-getPie")
    @ResponseBody
    public String getPie() { //ajax 默认为GetMapping
        System.out.println("thumb-up-getPie");
        List<ThumbUp> thumbUps = thumbUpService.getAll();
        List<String> data=new ArrayList<>();//id集合
        for (ThumbUp thum: thumbUps) {
            data.add("['博客id "+thum.getBlogid()+"',"+thum.getUpNum()+"]");
        }
        String  option=  HighchartsUtil.getPie(data);
        System.out.println(option);
        return  option;
    }
}
