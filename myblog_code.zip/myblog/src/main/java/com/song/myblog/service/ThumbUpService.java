package com.song.myblog.service;

import com.song.myblog.bean.ThumbUp;

import java.util.List;

//点赞统计
public interface ThumbUpService {
    List<ThumbUp> getAll();
}
