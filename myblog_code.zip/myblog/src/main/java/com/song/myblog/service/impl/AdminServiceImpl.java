package com.song.myblog.service.impl;

import com.song.myblog.bean.Admin;
import com.song.myblog.mapper.AdminMapper;
import com.song.myblog.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminMapper adminMapper;
    @Override
    public Admin getAdminByNameAndPwd(String name, String pwd) {
        return   adminMapper.getAdminByNameAndPwd(name,pwd);
    }

    @Override
    public List<Admin> getAll() {
        return adminMapper.getAll();
    }
}
