package com.song.myblog.service.impl;

import com.song.myblog.bean.Blog;
import com.song.myblog.mapper.BlogMapper;
import com.song.myblog.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class BlogServiceImpl implements BlogService {
    @Autowired
    private BlogMapper blogMapper;

    @Override
    public List<Blog> getAll() {
        return blogMapper.getAll();
    }
    @Override
    public void update(Blog blog) {
        blogMapper.update(blog);
    }
    @Override
    public void save(Blog blog) {
        blog.setTime(new Date());
        blogMapper.save(blog);
    }

    @Override
    public void deleteById(int id) {
        blogMapper.deleteById(id);
    }


}
