package com.song.myblog.service;

import com.song.myblog.bean.Admin;

import java.util.List;

public interface AdminService {
    Admin getAdminByNameAndPwd(String name, String pwd);

    List<Admin> getAll();
}
