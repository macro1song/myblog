package com.song.myblog.bean;

import lombok.Data;

/**
 *  用户表  tb_user
 */
@Data
public class User {
    private Integer id ;//主键自增
    private String name;//用户名
    private String pwd ; //密码
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pwd='" + pwd + '\'' +
                '}';
    }
}
