package com.song.myblog.bean;

import com.song.myblog.util.Constant;
import com.song.myblog.util.TimeUtil;
import lombok.Data;

import java.util.Date;

/**
 * 文章表  tb_Blog 文章管理
 */
@Data
public class Blog {
    private int id;//主键自增
    private String title;//标题
    private int type; //分类表tb_blog_type的id
    private String typestr;
    private String author;//文章作者
    private String content;//文章内容
    private String brief;//文章内容简略
    private Date time;//发表时间
    private String datetime;//发表时间

    public void setType(int type) {
        this.type = type;
        typestr = Constant.BLOG_TYPES[type - 1];//下标从0开始
    }

    public void setContent(String content) {
        this.content = content;
        brief = content.length() > Constant.BLOG_BRIEF_LEN ? content.substring(0, Constant.BLOG_BRIEF_LEN) + "..." : content;
    }

    public void setTime(Date time) {//格林威治时间时间 CST
        this.time = time;
        datetime = TimeUtil.format(time);
    }

    @Override
    public String toString() {
        return "Blog{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", type=" + type +
                ", typestr='" + typestr + '\'' +
                ", author='" + author + '\'' +
                ", content='" + content + '\'' +
                ", brief='" + brief + '\'' +
                ", time=" + time +
                ", datetime='" + datetime + '\'' +
                '}';
    }
}
