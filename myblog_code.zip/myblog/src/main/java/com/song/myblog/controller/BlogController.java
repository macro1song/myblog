package com.song.myblog.controller;

import com.song.myblog.bean.Blog;
import com.song.myblog.bean.Message;
import com.song.myblog.service.BlogService;
import com.song.myblog.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

//文章管理
@Controller
public class BlogController {
    @Autowired
    private BlogService blogService;

    @PostMapping("/blog-list")
    @ResponseBody
    public Message getAll(HttpSession session) {
        System.out.println("getAll:");
        List<Blog> blogs = blogService.getAll();
        System.out.println("blogs:" + blogs);
        if (null == blogs) {
            return new Message(Constant.MSG_NO, "no");
        }
        session.setAttribute("blogs", blogs);
        session.setAttribute("blogCount", blogs.size());// 共有数据
        return new Message(Constant.MSG_OK, "ok");
    }

    @PostMapping("/blog-save")
    public String blogAdd(Blog blog) {
        System.out.println("blog-save:" + blog);
        blogService.save(blog);
        return "ok";
    }

    @PostMapping("/blog-del")
    @ResponseBody
    public Message blogDel(int id) {
        System.out.println("blog-del: " + id);
        Message msg = new Message();
        blogService.deleteById(id);
        msg.setMsg("博客删除成功!");
        System.out.println(msg);
        return msg;
    }

    @PostMapping("/blog-edit")
    @ResponseBody
    public Message blogEdit(Blog edtblog , HttpSession session) {
        System.out.println("blog-edit:" + edtblog);
        Message msg = new Message();
        blogService.update(edtblog);//更新数据库
        //更新session
        List<Blog> blogs = (List<Blog>) session.getAttribute("blogs");
        for(int i=0;i<blogs.size() ;i++){
            if (blogs.get(i).getId() == edtblog.getId()) {
                blogs.set(i,edtblog);
                session.setAttribute("blogs", blogs);
                break;
            }
        }
        msg.setMsg("博客内容修改成功!");
        System.out.println(msg);
        return msg;
    }

    @GetMapping("/blog-get")//给session设置当前修改的对象
    @ResponseBody
    public Message getBlog(int id, HttpSession session) {
        System.out.println("getBlog id:" + id);
        List<Blog> blogs = (List<Blog>) session.getAttribute("blogs");
        for (Blog blog : blogs) {
            if (blog.getId() == id) {
                session.setAttribute("editBlog", blog);
                System.out.println("editBlog:" + blog);
                return new Message(Constant.MSG_OK, "ok");
            }
        }
        return new Message(Constant.MSG_NO, "no");
    }
}
