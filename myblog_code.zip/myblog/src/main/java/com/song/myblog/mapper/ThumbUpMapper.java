package com.song.myblog.mapper;

import com.song.myblog.bean.ThumbUp;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ThumbUpMapper {

    @Select("SELECT blogId ,COUNT(*) as  upNum FROM tb_thumb_up GROUP BY blogId")
    List<ThumbUp> getAll();
}

