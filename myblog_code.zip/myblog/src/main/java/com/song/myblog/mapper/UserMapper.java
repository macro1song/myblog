package com.song.myblog.mapper;


import com.song.myblog.bean.User;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserMapper {

    @Select("SElECT * FROM tb_user")
    List<User> getAll();
}

