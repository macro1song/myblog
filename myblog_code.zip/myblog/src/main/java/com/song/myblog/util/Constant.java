package com.song.myblog.util;

public class Constant {
    //for the Message
    public static  int MSG_OK=200;
    public static  int MSG_NO=500;

    //文章内容简略长度
    public static  int BLOG_BRIEF_LEN=35;


    //SimpleDateFormat pattern 比如:博客发表时间
    public static  String  PATTERN="yyyy-MM-dd HH:mm:ss";

    //由于分类功能不是动态的暂时定义为常量, 分类表 tb_blog_type
    public static  String[] BLOG_TYPES={"热门文章" ,"经济动态","最新文章","零售商业"};
    public static  String[] ADMIN_ROLES={"超级管理员" ,"管理员" };

}
