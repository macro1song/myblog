package com.song.myblog.bean;

import com.song.myblog.util.Constant;
import lombok.Data;

//for /*文章-删除*/ 等 ajax msg
@Data
public class Message {
    private Integer code ;//  返回的数据的响应码
    private String msg ;

    public Message() {
        code= Constant.MSG_OK;//默认ok
    }
    public Message(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
    @Override
    public String toString() {
        return "Message{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                '}';
    }
}
