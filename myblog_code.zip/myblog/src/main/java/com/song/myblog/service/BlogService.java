package com.song.myblog.service;

import com.song.myblog.bean.Blog;

import java.util.List;
//文章管理
public interface BlogService {
    List<Blog> getAll();
    void save(Blog blog);

    void deleteById(int id);

    void update(Blog blog);
}
