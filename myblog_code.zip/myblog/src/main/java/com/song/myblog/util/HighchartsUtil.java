package com.song.myblog.util;

import java.util.List;

public class HighchartsUtil {

    public static String getColumn(String title, String subtitle, List<Integer> xAxis, String yAxis, List<Integer> data, String dataName) {
        String optin = "{\n" +
                "    chart: {\n" +
                "        renderTo: 'container',\n" +
                "        type: 'column',\n" +
                "        margin: 75,\n" +
                "        options3d: {\n" +
                "            enabled: true,\n" +
                "            alpha: 15,\n" +
                "            beta: 15,\n" +
                "            depth: 50,\n" +
                "            viewDistance: 25\n" +
                "        }\n" +
                "    },\n" +
                "    title: {\n" +
                "        text: '" + title + "'\n" +
                "    },\n" +
                "    subtitle: {\n" +
                "        text: '" + subtitle + "'\n" +
                "    },\n" +
                "    plotOptions: {\n" +
                "        column: {\n" +
                "            depth: 25\n" +
                "        }\n" +
                "    },\n" +
                "    xAxis: {\n" +
                "        categories: " + xAxis + "\n" +
                "    },\n" +
                "    yAxis: {\n" +
                "        title: {\n" +
                "            text: '" + yAxis + "'\n" +
                "        }\n" +
                "    },\n" +
                "    series: [{\n" +
                "        name:'" + dataName + "',\n" +
                "        data: " + data + "\n" +
                "    }]\n" +
                "}";
        return optin;
    }

    public static String getColumn(List<Integer> xAxis, List<Integer> data) {
        String title = "点赞统计3D柱状图";
        String subtitle = "About every article statistics";
        String yAxis = "点赞数";
        String dataName = "文章id";
        return getColumn(title, subtitle, xAxis, yAxis, data, dataName);
    }

    private static String getPie(String title, String name, List<String> data) {
        return "{\n" +
                "\tchart: {\n" +
                "\t\ttype: 'pie',\n" +
                "\t\toptions3d: {\n" +
                "\t\t\tenabled: true,\n" +
                "\t\t\talpha: 45,\n" +
                "\t\t\tbeta: 0\n" +
                "\t\t}\n" +
                "\t},\n" +
                "\ttitle: {\n" +
                "\t\ttext: '" + title + "'\n" +
                "\t},\n" +
                "\ttooltip: {\n" +
                "\t\tpointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'\n" +
                "\t},\n" +
                "\tplotOptions: {\n" +
                "\t\tpie: {\n" +
                "\t\t\tallowPointSelect: true,\n" +
                "\t\t\tcursor: 'pointer',\n" +
                "\t\t\tdepth: 35,\n" +
                "\t\t\tdataLabels: {\n" +
                "\t\t\t\tenabled: true,\n" +
                "\t\t\t\tformat: '{point.name}'\n" +
                "\t\t\t}\n" +
                "\t\t}\n" +
                "\t},\n" +
                "\tseries: [{\n" +
                "\t\ttype: 'pie',\n" +
                "\t\tname: '" + name + "',\n" +
                "\t\tdata: " + data + "\n" +
                "\t}]" +
                "}";
    }

    public static String getPie(List<String> data) {
        String title = "点赞统计3D饼状图";
        String name = "用户点赞数";
        return getPie(title, name, data);
    }

}
