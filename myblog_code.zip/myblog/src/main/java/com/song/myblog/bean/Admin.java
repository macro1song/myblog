package com.song.myblog.bean;

import com.song.myblog.util.Constant;
import lombok.Data;

/**
 * tb_admin  后台登录管理员表
 */
@Data
public class Admin {
    private Integer id;//主键自增
    private String name;//用户名
    private String pwd; //密码
    private Integer role;//权限,(0管理员 默认,1不可用,)
    private String roleStr;//权限,(0管理员 默认,1不可用,)

    public void setRole(Integer role) {
        this.role = role;
        roleStr = Constant.ADMIN_ROLES[role];
    }
    @Override
    public String toString() {
        return "Admin{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pwd='" + pwd + '\'' +
                ", role=" + role +
                '}';
    }
}
