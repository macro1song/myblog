package com.song.myblog.controller;

import com.song.myblog.bean.Admin;
import com.song.myblog.bean.Message;
import com.song.myblog.service.AdminService;
import com.song.myblog.util.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService ;

    @PostMapping("/admin-login")
    @ResponseBody
    public Map  adminLogin( String name, String pwd,   HttpSession session) {
        Map<String, Object> result = new HashMap<String, Object>();
        System.out.println("adminLogin:" +name+" : " +pwd);
        Admin admin = adminService.getAdminByNameAndPwd(name,pwd);
        System.out.println("admin:"+admin);
        if(null == admin) {
            result.put("msg","no");
            return result;
        }
        session.setAttribute("admin",admin);
        result.put("msg","ok");
        return result;
    }

    @PostMapping("/admin-list")
    @ResponseBody
    public Message  getAll(    HttpSession session) {
        System.out.println("getAll:");
        List<Admin> admins = adminService.getAll();
        System.out.println("admins:" + admins);
        if (null == admins) {
            return new Message(Constant.MSG_NO, "no");
        }
        session.setAttribute("admins", admins);
        session.setAttribute("adminCount", admins.size());// 共有数据
        return new Message(Constant.MSG_OK, "ok");
    }

    @RequestMapping("/admin-loginout")
    public String adminLoginout(HttpSession session) {
        // 所谓的退出就是session失效
        session.invalidate();
        return "redirect:/index.html" ;
    }
}
