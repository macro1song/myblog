package com.song.myblog.service.impl;

import com.song.myblog.bean.ThumbUp;
import com.song.myblog.mapper.ThumbUpMapper;
import com.song.myblog.service.ThumbUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ThumbUpServiceImpl implements ThumbUpService {
    @Autowired
    private ThumbUpMapper thumbUpMapper;
    @Override
    public List<ThumbUp> getAll() {
        return thumbUpMapper.getAll();
    }
}
