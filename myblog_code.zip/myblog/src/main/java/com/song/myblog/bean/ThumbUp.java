package com.song.myblog.bean;

import lombok.Data;

/**
 * 点赞表 tb_thumb_up 点赞统计
 */
@Data
public class ThumbUp {
    private int blogid;//被点赞的id  文章表tb_Blog的id
    private int upNum;//被点赞的次数

    public ThumbUp(int blogid, int upNum) {
        this.blogid = blogid;
        this.upNum = upNum;
    }

    @Override
    public String toString() {
        return "ThumbUp{" +
                "blogid=" + blogid +
                ", upNum=" + upNum +
                '}';
    }
}
