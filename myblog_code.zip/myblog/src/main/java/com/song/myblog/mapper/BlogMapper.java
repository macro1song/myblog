package com.song.myblog.mapper;

import com.song.myblog.bean.Blog;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface BlogMapper {

    @Select("SElECT * FROM tb_Blog")
    List<Blog> getAll();

    @Insert("INSERT INTO tb_Blog(title,type,author,content,time) values(#{title},#{type},#{author},#{content},#{time})")
    void save(Blog blog);

    @Delete("DELETE FROM tb_Blog WHERE id=#{id}")
    void deleteById(int id);

    @Update("UPDATE tb_blog SET title=#{title} ,type=#{type},author=#{author},content=#{content} WHERE id=#{id}")
    void update(Blog blog);
}

