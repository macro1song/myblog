package com.song.myblog.service;

import com.song.myblog.bean.User;

import java.util.List;

public interface UserService {
    List<User> getAll();
}
