package com.song.myblog.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtil {
    public static SimpleDateFormat sdf = new SimpleDateFormat(Constant.PATTERN);
    public static String format(Date date) {
        return sdf.format(date);
    }
}
